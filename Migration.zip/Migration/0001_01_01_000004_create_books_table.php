public function up(): void
{
    Schema::create('books', function (Blueprint $table) {
        $table->id();
        $table->foreignId('author_id')->constrained('authors')->onDelete('cascade');
        $table->string('title');
        $table->integer('year');
        $table->timestamps();
    });
}