namespace Database\Seeders;

use Illuminate\Database\Seeder;
use App\Models\Author;

class AuthorSeeder extends Seeder
{
    public function run(): void
    {
        $authors = [
            ['name' => 'J.K. Rowling', 'country' => 'United Kingdom'],
            ['name' => 'Tere Liye', 'country' => 'Indonesia'],
            ['name' => 'Andrea Hirata', 'country' => 'Indonesia'],
            ['name' => 'Stephen King', 'country' => 'United States'],
            ['name' => 'Agatha Christie', 'country' => 'United Kingdom'],
        ];

        foreach ($authors as $author) {
            Author::create($author);
        }
    }
}