namespace Database\Seeders;

use Illuminate\Database\Seeder;
use App\Models\Book;

class BookSeeder extends Seeder
{
    public function run(): void
    {
        $books = [
            ['author_id' => 1, 'title' => 'Harry Potter and the Sorcerer\'s Stone', 'year' => 1997],
            ['author_id' => 2, 'title' => 'Hafalan Shalat Delisa', 'year' => 2005],
            ['author_id' => 3, 'title' => 'Laskar Pelangi', 'year' => 2005],
            ['author_id' => 4, 'title' => 'The Shining', 'year' => 1977],
            ['author_id' => 5, 'title' => 'Murder on the Orient Express', 'year' => 1934],
        ];

        foreach ($books as $book) {
            Book::create($book);
        }
    }
}