namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Genre extends Model
{
    public static function allGenres()
    {
        return [
            ['id' => 1, 'name' => 'Fantasy', 'description' => 'Magical and supernatural themes'],
            ['id' => 2, 'name' => 'Romance', 'description' => 'Love and emotional relationships'],
            ['id' => 3, 'name' => 'Mystery', 'description' => 'Solving a crime or puzzle'],
            ['id' => 4, 'name' => 'Science Fiction', 'description' => 'Futuristic technology and space'],
            ['id' => 5, 'name' => 'Biography', 'description' => 'Life story of a real person'],
        ];
    }
}