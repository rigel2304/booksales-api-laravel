namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Author extends Model
{
    public static function allAuthors()
    {
        return [
            ['id' => 1, 'name' => 'J.K. Rowling', 'country' => 'United Kingdom'],
            ['id' => 2, 'name' => 'Tere Liye', 'country' => 'Indonesia'],
            ['id' => 3, 'name' => 'Andrea Hirata', 'country' => 'Indonesia'],
            ['id' => 4, 'name' => 'Stephen King', 'country' => 'United States'],
            ['id' => 5, 'name' => 'Agatha Christie', 'country' => 'United Kingdom'],
        ];
    }
}